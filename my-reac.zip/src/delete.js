import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";
import {Link} from 'react-router-dom'
import MaterialTable from 'material-table';
import { style } from '@material-ui/system';
//import PostCustomer from './PostCustomer';
class Table extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }

  }

  componentDidMount() {
    const url = "http://localhost:9122/customer/delete";
    fetch(url, {
      method: "DELETE"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
  }
}