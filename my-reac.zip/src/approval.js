import React from 'react';
//import './App.css';
import Ar from './ar';

class Approval extends React.Component {
 
    render() {
        return (
            
            <div >
        
            <div className="text-center " >
           
                <h1 style={{paddingTop:20}}>Application Approval</h1>

                <h3 style={{marginTop:100}}>Approved by User <input id="check" type="checkbox" style={{padding: 20}}
                     /></h3>
                <input id="appeal" type="button" value="Appeal" className="btn btn-danger" />
                <input id="dd" type="button" value="Next" disabled className="btn btn-success" />

                    <form id="ds" >
                        <div style={{margin:50,backgroundColor: '#FFFFFF' ,width:600,marginLeft: 320,padding: 5}}>
                            <h2>Appeal Section</h2>

                            <div className="form-group">

                                <div >
                                    <div>
                                        <label>
                                            <h4 style={{marginLeft:10}}>Reason for Appeal</h4>
                                        </label>
                                    

                                    <div style={{marginTop:15,marginLeft:30}}>

                                        <select className="form-control" id="product">

                                            <option>Want to Increase Credit Limit</option>
                                            <option>Want to Decrease Credit Limit</option>
                                            <option>Want to Reduce Annual Charges</option>

                                        </select>
                                    </div>
                                    </div>


                                </div>


                            </div>
                            <a href="docver.html" target="_blank" type="button" className="btn btn-success">Submit</a>
                            <a target="_blank" type="button" className="btn btn-danger" >Cancel</a>


                        </div>
                    </form>
                    </div>
                    </div>
                    
            
        );
    }
};
export default Approval;