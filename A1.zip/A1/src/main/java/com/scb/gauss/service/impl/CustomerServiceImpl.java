package com.scb.gauss.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.gauss.bean.Customer;
import com.scb.gauss.dao.CustomerDAO;
import com.scb.gauss.service.CustomerService;


@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO cusDAO;
	
	static
	{
		System.out.println("In Service");
	}

	@Override
	public int add(Customer customer) {
		return cusDAO.add(customer);
	}
	@Override
	public List<Customer> list() {
		return cusDAO.list();
	}
	@Override
	public int delete(int id) {
		return cusDAO.delete(id);
	}
	@Override
	public Customer get(int id) {
		return cusDAO.get(id);
	}

	}


